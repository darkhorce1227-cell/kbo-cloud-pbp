@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0KBO_PBP_20261030_collect.ps1"
echo.
if errorlevel 1 (
  echo Collection failed. Please send the error message.
) else (
  echo Collection finished. Upload the ZIP or share its SHA256.
)
pause
