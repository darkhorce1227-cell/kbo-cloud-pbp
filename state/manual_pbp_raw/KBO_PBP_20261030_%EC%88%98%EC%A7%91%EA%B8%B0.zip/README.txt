﻿KBO PBP 2026-10-30 (Samsung @ KIA, Playoff G4) original Naver collector

1. Extract ZIP into a NEW empty folder on the same Windows PC/network where 10/29 collection succeeded.
2. Double-click KBO_PBP_20261030_run.bat.
3. On SUCCESS, attach the generated kbo_20261030_SSHT_raw_*.zip in ChatGPT.

This captures the original date schedule + nine inning relay JSONs (11 ZIP members),
checks game ID 55551030SSHT02026, RESULT/statusNum=4, away 2/home 4,
9th-inning GAME_END(type=99), scoreboard and all SHA256 hashes.
KIA's 9th bottom was not played because it won at home; this is valid.
This file is a CAPTURE TOOL, NOT original PBP data. It cannot run in ChatGPT's environment.
Do not commit raw ZIP directly to GitHub until the 10/30 importer is prepared.
Static checks performed; live Windows execution not tested here.
