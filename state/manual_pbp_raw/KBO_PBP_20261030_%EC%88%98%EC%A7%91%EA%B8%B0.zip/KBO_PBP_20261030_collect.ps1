﻿# KBO 2026-10-30 Samsung @ KIA, PO game 4.
# Captures REAL Naver schedule + 9 original inning relay JSONs.
# Fails closed when the game, score, 9 innings, or GAME_END cannot be verified.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$TargetDate = '2026-10-30'
$ExpectedAway = 'SS'
$ExpectedHome = 'HT'
$ExpectedAwayRuns = 2
$ExpectedHomeRuns = 4
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$Root = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($Root)) { $Root = (Get-Location).Path }
$Work = Join-Path ([System.IO.Path]::GetTempPath()) ('kbo_pbp_20261030_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path (Join-Path $Work 'relays') -Force | Out-Null

function Download-Json([string]$Url, [string]$OutputPath) {
    $headers = @{
        'User-Agent' = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36'
        'Accept' = 'application/json, text/plain, */*'
        'Origin' = 'https://m.sports.naver.com'
        'Referer' = 'https://m.sports.naver.com/'
    }
    $lastError = $null
    for ($try = 1; $try -le 3; $try++) {
        try {
            $response = Invoke-WebRequest -Uri $Url -Method Get -Headers $headers -TimeoutSec 20 -UseBasicParsing
            if ([int]$response.StatusCode -ne 200) { throw "HTTP $($response.StatusCode)" }
            $content = [string]$response.Content
            if ([string]::IsNullOrWhiteSpace($content)) { throw 'Empty response' }
            $parsed = $content | ConvertFrom-Json
            if ($null -eq $parsed -or $parsed.success -ne $true) { throw 'Naver success != true' }
            [System.IO.File]::WriteAllText($OutputPath, $content, $Utf8NoBom)
            return $parsed
        } catch {
            $lastError = $_.Exception.Message
            Write-Host "  Attempt $try failed: $lastError"
            if ($try -lt 3) { Start-Sleep -Seconds 2 }
        }
    }
    throw "Naver API failed after 3 attempts: $lastError"
}

function Sha256([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -Path $Path).Hash.ToLowerInvariant()
}

function Total-Runs($Values) {
    if ($null -eq $Values) { throw 'Missing inningScore' }
    $sum = 0; $found = 0
    foreach ($entry in $Values.PSObject.Properties) {
        $value = [string]$entry.Value
        if ($value -eq '-') { continue }
        if ($value -notmatch '^\d+$') { throw "Invalid inning run value: $value" }
        $sum += [int]$value; $found++
    }
    if ($found -lt 8) { throw 'Too few innings in scoreboard' }
    return $sum
}

try {
    Write-Host '=== KBO PBP 2026-10-30 offline raw capture ==='
    $scheduleUrl = 'https://api-gw.sports.naver.com/schedule/games?fields=basic%2CcategoryName%2CstatusNum&upperCategoryId=kbaseball&fromDate=2026-10-30&toDate=2026-10-30'
    $scheduleFile = Join-Path $Work 'schedule.json'
    Write-Host 'Fetching Naver schedule...'
    $schedule = Download-Json $scheduleUrl $scheduleFile
    if ($null -eq $schedule.result -or $null -eq $schedule.result.games) { throw 'Schedule missing result.games' }

    $matching = @($schedule.result.games | Where-Object {
        [string]$_.gameDate -eq $TargetDate -and
        [string]$_.awayTeamCode -eq $ExpectedAway -and
        [string]$_.homeTeamCode -eq $ExpectedHome -and
        [string]$_.gameId -match '^[0-9]{8}[A-Z]{4}0[0-9]{4}$'
    })
    if ($matching.Count -ne 1) { throw "Expected exactly one Samsung@KIA game on $TargetDate, found $($matching.Count)" }
    $game = $matching[0]
    $gameId = [string]$game.gameId
    if ($gameId -ne '55551030SSHT02026') { throw "Unexpected gameId: $gameId" }
    if ([string]$game.statusCode -ne 'RESULT' -or [int]$game.statusNum -ne 4) { throw 'Game not finalized on Naver schedule' }
    if ([int]$game.awayTeamScore -ne $ExpectedAwayRuns -or [int]$game.homeTeamScore -ne $ExpectedHomeRuns) {
        throw "Unexpected final score on Naver: $($game.awayTeamScore)-$($game.homeTeamScore)"
    }
    # statusInfo is a localized display string; do not use it as completion proof.
    # Reliable gates: RESULT + statusNum=4, nine relays, GAME_END(type=99), final score.
    if ([string]::IsNullOrWhiteSpace([string]$game.statusInfo)) { throw 'Missing schedule statusInfo' }
    Write-Host "Naver statusInfo: $($game.statusInfo) (RESULT+4 confirmed)"
    Write-Host "Verified schedule: $gameId, Samsung 2 - KIA 4"

    $innings = @()
    for ($inning = 1; $inning -le 9; $inning++) {
        Write-Host "Fetching inning $inning / 9 ..."
        $relative = ('relays/inning_{0:D2}.json' -f $inning)
        $target = Join-Path $Work (('relays\inning_{0:D2}.json' -f $inning))
        $relayUrl = "https://api-gw.sports.naver.com/schedule/games/$gameId/relay?inning=$inning"
        $response = Download-Json $relayUrl $target
        if ($null -eq $response.result -or $null -eq $response.result.textRelayData) { throw "Missing textRelayData in inning $inning" }
        $relay = $response.result.textRelayData
        if ([string]$relay.gameId -ne $gameId) { throw "Wrong gameId in inning $inning relay" }
        if ($null -eq $relay.textRelays) { throw "Missing textRelays in inning $inning" }
        $terminal = $false
        foreach ($block in @($relay.textRelays)) {
            if ($null -eq $block.textOptions) { continue }
            foreach ($event in @($block.textOptions)) {
                if ([string]$event.type -eq '99') { $terminal = $true }
            }
        }
        if ($inning -lt 9 -and $terminal) { throw "Premature GAME_END in inning $inning" }
        if ($inning -eq 9) {
            if (-not $terminal) { throw 'Missing GAME_END(type=99) in 9th inning' }
            if ($null -eq $relay.inningScore) { throw 'Missing final inningScore' }
            $away = Total-Runs $relay.inningScore.away
            $homeRunsFromRelay = Total-Runs $relay.inningScore.home
            if ($away -ne $ExpectedAwayRuns -or $homeRunsFromRelay -ne $ExpectedHomeRuns) {
                throw "PBP scoreboard mismatch: away=$away home=$homeRunsFromRelay"
            }
        }
        $info = Get-Item $target
        $innings += [ordered]@{
            inning = $inning
            file = $relative
            bytes = [int64]$info.Length
            sha256 = Sha256 $target
            game_end_type_99 = [bool]$terminal
        }
    }

    $capturedAt = [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
    $manifest = [ordered]@{
        schema = 'kbo_naver_raw_relay_capture_v1'
        target_date_kst = $TargetDate
        game_id = $gameId
        captured_at_utc = $capturedAt
        inning_count = 9
        schedule_sha256 = Sha256 $scheduleFile
        game_end_verified_in_relay = $true
        innings = $innings
    }
    $manifestFile = Join-Path $Work 'manifest.json'
    $json = ConvertTo-Json -InputObject $manifest -Depth 15
    [System.IO.File]::WriteAllText($manifestFile, $json + "`n", $Utf8NoBom)

    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $kst = [DateTime]::UtcNow.AddHours(9).ToString('yyyyMMdd_HHmmss')
    $filename = 'kbo_20261030_SSHT_raw_' + $kst + '.zip'
    $out = Join-Path $Root $filename
    if (Test-Path $out) { throw "Output exists, refusing overwrite: $out" }
    [System.IO.Compression.ZipFile]::CreateFromDirectory($Work, $out, [System.IO.Compression.CompressionLevel]::Optimal, $false)
    $zip = [System.IO.Compression.ZipFile]::OpenRead($out)
    try {
        $names = @($zip.Entries | ForEach-Object { $_.FullName.Replace('\','/') })
        $required = @('manifest.json','schedule.json') + @(1..9 | ForEach-Object { 'relays/inning_{0:D2}.json' -f $_ })
        if ($names.Count -ne 11) { throw "ZIP has $($names.Count) members, expected 11" }
        foreach ($needed in $required) { if ($names -notcontains $needed) { throw "ZIP missing: $needed" } }
    } finally { $zip.Dispose() }
    Write-Host ''
    Write-Host 'SUCCESS - Original 9-inning ZIP captured and verified.' -ForegroundColor Green
    Write-Host "ZIP: $out"
    Write-Host "SHA256: $(Sha256 $out)"
    Write-Host "GAME_ID: $gameId"
    Write-Host 'Upload the UNMODIFIED ZIP to this ChatGPT conversation for validation and GitHub import.'
} catch {
    Write-Host ''
    Write-Host "FAILED - no validated ZIP: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} finally {
    if (Test-Path $Work) { Remove-Item -LiteralPath $Work -Recurse -Force -ErrorAction SilentlyContinue }
}
